LakeShark map builder

Needs Python 3. No other install.

1. Fetch the tiles for your area (the site gives you this line with your
   own box already in it):

     python fetch_tiles.py tiles --bbox=W,S,E,N --min-zoom 6 --max-zoom 14

2. Pack them:

     python build_pmtiles.py tiles map.pmtiles --simplify --leaf-size 256

3. Put map.pmtiles on the Flipper SD at:

     apps_data/lakeshark_p25/map.pmtiles

   If you already run ZeroMesh you can skip this. The app falls back to
   ZeroMesh's copy.

Tiles come from tiles.versatiles.org, which is free to use. Be reasonable
with the rate: the fetcher defaults to 5 requests a second.
